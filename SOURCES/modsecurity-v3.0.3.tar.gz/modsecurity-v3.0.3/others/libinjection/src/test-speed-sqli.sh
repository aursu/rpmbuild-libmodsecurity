#!/bin/sh
set -e
${VALGRIND} ./testspeedsqli
